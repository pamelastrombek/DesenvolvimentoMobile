package com.example.carrinho;

import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEventSource;

public interface GameView extends Drawable.Callback, KeyEvent.Callback, AccessibilityEventSource {

    void OnDetachedFromWindow() throws InterruptedException;
}
